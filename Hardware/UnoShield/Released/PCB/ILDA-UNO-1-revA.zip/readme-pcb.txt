Scrootch.Me
P/N: ILDA-UNO-1
Rev: A

4 layer board

2.1" x 2.8"
Thickness 0.062" (nominal)

Solder Mask (Green)
Silk Screen (White)
SMT Components one side

Gerbers are: *.G*
NC Drill tapes are: *.TXT

See Board Details plot (*.GM16) for additional information.

Questions:
        Joe Fitzpatrick
        jfitzpat@scrootchme.com

Files included in this zip:

readme-pcb.txt    This file
UnoShield.GTL     Top Layer
UnoShield.GP1     Ground Plane
UnoShield.GP2     Power Plane
UnoShield.GBL     Bottom Layer
UnoShield.GTO     Top Overlay
UnoShield.GTP     Top Paste
UnoShield.GTS     Top Solder
UnoShield.GBO     Bottom Overlay
UnoShield.GBS     Bottom Solder
UnoShield.GM1     Board Outline
UnoShield.GM2     Board Dimensions
UnoShield.GM16    Board Details
UnoShield.GD1     Drill Drawing
UnoShield.GG1     Drill Guide
UnoShield.TXT     NC Drill
